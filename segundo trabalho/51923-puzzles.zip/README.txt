Este programa não funciona para caractéres com acentos, pelo facto de que estes dão problemas aquando do seu armazenamento em memória. 
Como tal, o programa foi foi testado versões ligeiramente modificadas (uma simples substituição dos caracteres com acentos pelos mesmo, 
mas sem acentos, ex: Ó -> O) dos ficheiros pela professora proporcionados para acomodar este problema.
Tenho também a dizer que o programa não foi completamente testado, e que podem haver bugs / funcionalidades que não estão bem implement-
tadas, pelo que o resultado pode não ser o esperado.
Espero que a professsora entenda.

ass: Henrique Rosa :)